# train-ticketing-system
1.unzip the floder 
2.open in any editor like vs ,pycharm etc.
3.use mysql for database
